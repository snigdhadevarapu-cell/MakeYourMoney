import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, Smartphone, X, Check, Apple } from 'lucide-react';

export const PWAInstallModal: React.FC<{ isOpen: boolean; onClose: () => void }> = ({ isOpen, onClose }) => {
  const { isInstallable, isIOS, isAndroid, install } = usePWAInstall();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-md bg-white rounded-3xl p-6 sm:p-7 shadow-2xl border border-slate-100 flex flex-col text-slate-800 animate-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between pb-3 border-b border-slate-100">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-blue-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-blue-500/20">
              <Download className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-base text-slate-900 leading-tight">Install Mobile App</h3>
              <p className="text-xs text-slate-500">Android APK WebApp & iOS Support</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-slate-400 hover:text-slate-700 rounded-xl hover:bg-slate-100 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="py-5 space-y-4">
          <div className="p-4 rounded-2xl bg-blue-50/70 border border-blue-100 text-xs text-blue-900 space-y-2">
            <p className="font-bold flex items-center gap-2 text-blue-800">
              <Smartphone className="w-4 h-4 text-blue-600 shrink-0" />
              Direct Phone & Chrome APK Installation
            </p>
            <p className="text-slate-600 leading-relaxed">
              Install <strong>Make your money</strong> directly from Chrome onto your Android phone as a standalone mobile app without needing Google Play Store!
            </p>
          </div>

          {isInstallable ? (
            <button
              onClick={async () => {
                const ok = await install();
                if (ok) onClose();
              }}
              className="w-full py-3.5 px-4 bg-blue-600 hover:bg-blue-700 active:scale-[0.99] text-white font-bold text-sm rounded-2xl flex items-center justify-center gap-2.5 transition-all shadow-md shadow-blue-500/25 cursor-pointer"
            >
              <Download className="w-4 h-4" />
              <span>Install App on this Device</span>
            </button>
          ) : isAndroid ? (
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1.5">
              <p className="font-bold text-slate-800">How to install on Android Chrome:</p>
              <ol className="list-decimal list-inside space-y-1 text-slate-600 leading-normal">
                <li>Tap the <strong>three dots (⋮)</strong> menu in Chrome.</li>
                <li>Tap <strong>"Install app"</strong> or <strong>"Add to Home screen"</strong>.</li>
                <li>Tap <strong>Install</strong> to download the APK icon to your app drawer.</li>
              </ol>
            </div>
          ) : isIOS ? (
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1.5">
              <p className="font-bold text-slate-800 flex items-center gap-1.5">
                <Apple className="w-4 h-4" /> How to install on iPhone / iPad (Safari):
              </p>
              <ol className="list-decimal list-inside space-y-1 text-slate-600 leading-normal">
                <li>Tap the <strong>Share</strong> button (box with upward arrow) at the bottom.</li>
                <li>Scroll down and tap <strong>"Add to Home Screen"</strong>.</li>
                <li>Tap <strong>Add</strong> in the top-right corner.</li>
              </ol>
            </div>
          ) : (
            <div className="p-3.5 bg-slate-50 rounded-2xl border border-slate-200 text-xs space-y-1.5">
              <p className="font-bold text-slate-800">Install via Browser:</p>
              <p className="text-slate-600">
                Click the install icon in your browser URL bar or select <strong>Menu &gt; Install Make your money</strong>.
              </p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2.5 text-[11px] text-slate-500 pt-1">
            <div className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Instant price alerts</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Zero lag offline mode</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>Full-screen app view</span>
            </div>
            <div className="flex items-center gap-1.5">
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span>No Play Store required</span>
            </div>
          </div>
        </div>

        <button
          onClick={onClose}
          className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition cursor-pointer"
        >
          Got it
        </button>
      </div>
    </div>
  );
};
